import React, { Component } from 'react'
import './App.css'
import List from './components/list'
// import events from './helpers/events'

class App extends Component {
  render() {
    return <List />
  }
}

export default App
